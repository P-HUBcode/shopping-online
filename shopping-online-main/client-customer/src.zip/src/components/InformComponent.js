import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import MyContext from '../contexts/MyContext';

class Inform extends Component {
    static contextType = MyContext;

    render() {
        return (
            <div className="border-bottom">
                <div className="float-left">
                    {this.context.token === '' ? (
                        <div>
                            <Link to='/login'>Login</Link> | <Link to='/signup'>Sign-up</Link> | <Link to='/active'>Active</Link>
                        </div>
                    ) : (
                        <div>
                            Hello <b>{this.context.customer && this.context.customer.name}</b> | 
                            <Link to='/home' onClick={() => this.lnkLogoutClick()}>Logout</Link> | 
                            <Link to='/myprofile'>My profile</Link> | 
                            <Link to='/myorders'>My orders</Link>
                        </div>
                    )}
                </div>
                <div className="float-right">
                    {/* CẬP NHẬT: Lấy độ dài mảng mycart từ context */}
                    <Link to='/mycart'>My cart</Link> have <b>{this.context.mycart ? this.context.mycart.length : 0}</b> items
                </div>
                <div className="float-clear" />
            </div>
        );
    }

    lnkLogoutClick() {
        this.context.setToken('');
        this.context.setCustomer(null);
        this.context.setMycart([]); // Xóa giỏ hàng khi logout (tùy chọn)
    }
}

export default Inform;